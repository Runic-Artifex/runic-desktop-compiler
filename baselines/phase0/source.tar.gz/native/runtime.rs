use crate::app;
use anyrender::{ImageRenderer, RenderContext, WindowRenderer};
use blitz_dom::{
    BaseDocument, DocGuard, DocGuardMut, Document, DocumentConfig, EventDriver, EventHandler,
};
use blitz_html::HtmlDocument;
use blitz_shell::{
    BlitzApplication, BlitzShellProxy, DataUriNetProvider, WindowConfig, create_default_event_loop,
};
use blitz_traits::{
    events::{DomEvent, DomEventData, EventState, UiEvent},
    node_id::NodeId,
    shell::{ColorScheme, Viewport},
};
use markup5ever::{LocalName, Namespace, QualName};
use serde_json::{Value, json};
use std::{io::Write, sync::Arc, time::Instant};

pub fn escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}
pub enum Kind {
    Text,
    Conditional(fn(&app::State) -> String),
    Attribute(&'static str, bool),
}
pub struct Binding {
    pub id: &'static str,
    pub kind: Kind,
    pub deps: &'static [usize],
    pub value: fn(&app::State) -> String,
}
fn attr(name: &str) -> QualName {
    QualName::new(None, Namespace::from(""), LocalName::from(name))
}
fn node(doc: &BaseDocument, id: &str) -> Option<NodeId> {
    doc.query_selector(&format!("[data-runic='{id}']"))
        .ok()
        .flatten()
}
fn cache(s: &app::State) -> Vec<String> {
    app::BINDINGS.iter().map(|b| (b.value)(s)).collect()
}
fn apply(
    doc: &mut BaseDocument,
    s: &app::State,
    changed: &[bool],
    previous: &mut [String],
) -> usize {
    let mut writes = 0;
    for (index, binding) in app::BINDINGS.iter().enumerate() {
        if app::OPTIMIZE && !binding.deps.iter().any(|&slot| changed[slot]) {
            continue;
        }
        let value = (binding.value)(s);
        // Visibility changes only mount/unmount when the condition changes.
        // Evaluating every binding in baseline mode must still preserve node identity.
        if previous[index] == value {
            continue;
        }
        previous[index] = value.clone();
        let Some(id) = node(doc, binding.id) else {
            continue;
        };
        let mut mutator = doc.mutate();
        match binding.kind {
            Kind::Text => mutator.set_inner_html(id, &escape(&value)),
            Kind::Conditional(children) => {
                let html = if value == "true" {
                    children(s)
                } else {
                    String::new()
                };
                mutator.set_inner_html(id, &html);
            }
            Kind::Attribute(name, boolean) => {
                if boolean && value == "false" {
                    mutator.clear_attribute(id, attr(name));
                } else {
                    mutator.set_attribute(id, attr(name), if boolean { "" } else { &value });
                }
            }
        }
        writes += 1;
    }
    writes
}
fn snapshot(doc: &BaseDocument, state: &app::State) -> Value {
    let mut elements = serde_json::Map::new();
    for &id in app::ELEMENTS {
        if let Some(n) = doc.query_selector(&format!("#{id}")).ok().flatten() {
            let nd = doc.get_node(n).unwrap();
            let rect = doc.get_client_bounding_rect(n);
            let text = nd.text_content();
            elements.insert(id.into(),json!({"text":text,"class":nd.attr("class".into()).unwrap_or(""),"disabled":nd.attr("disabled".into()).is_some(),"nodeIdentity":format!("{n:?}"),"rect":rect.map(|r|json!({"x":r.x,"y":r.y,"width":r.width,"height":r.height}))}));
        }
    }
    let focused = doc
        .get_focussed_node_id()
        .and_then(|id| doc.get_node(id))
        .and_then(|n| n.attr("id".into()))
        .map(str::to_owned);
    json!({"state":app::json(state),"elements":elements,"focused":focused,"irHash":app::IR_HASH})
}
struct Handler<'a> {
    state: &'a mut app::State,
    snapshots: &'a mut Vec<Value>,
    cache: &'a mut Vec<String>,
}
impl EventHandler for Handler<'_> {
    fn handle_event(
        &mut self,
        chain: &[NodeId],
        event: &mut DomEvent,
        doc: &mut dyn Document,
        event_state: &mut EventState,
    ) {
        if !matches!(event.data, DomEventData::Click(_)) {
            return;
        }
        let event_id = {
            let d = doc.inner();
            chain.iter().find_map(|&n| {
                let nd = d.get_node(n)?;
                if nd.attr("disabled".into()).is_some() {
                    return None;
                }
                let identity = nd.attr("data-runic".into())?;
                app::EVENTS
                    .iter()
                    .find_map(|&(id, e)| (id == identity).then_some((e, n)))
            })
        };
        let Some((e, target)) = event_id else {
            return;
        };
        if !app::enabled(e, self.state) {
            return;
        }
        let start = Instant::now();
        let changed = app::dispatch(self.state, e);
        let mut d = doc.inner_mut();
        // Supported controls are buttons outside forms. Blitz's default Click
        // action clears their focus; supply the Linux button focus contract and
        // suppress that default action. Disabled controls cannot dispatch here.
        event_state.prevent_default();
        let writes = apply(&mut d, self.state, &changed, self.cache);
        if app::enabled(e, self.state) {
            d.set_focus_to(target);
        } else {
            d.clear_focus();
        }
        d.resolve(0.0);
        let mut record = snapshot(&d, self.state);
        record["event"] = json!(e);
        record["writes"] = json!(writes);
        record["update_us"] = json!(start.elapsed().as_secs_f64() * 1e6);
        println!("NATIVE_EVENT {record}");
        self.snapshots.push(record.clone());
        if let Ok(file) = std::env::var("RUNIC_TRACE") {
            std::fs::write(file, serde_json::to_string_pretty(&self.snapshots).unwrap()).unwrap();
        }
        event_state.request_redraw();
    }
}
struct Native {
    doc: HtmlDocument,
    state: app::State,
    snapshots: Vec<Value>,
    cache: Vec<String>,
}
impl Document for Native {
    fn inner(&self) -> DocGuard<'_> {
        self.doc.inner()
    }
    fn inner_mut(&mut self) -> DocGuardMut<'_> {
        self.doc.inner_mut()
    }
    fn handle_ui_event(&mut self, event: UiEvent) {
        EventDriver::new(
            &mut self.doc,
            Handler {
                state: &mut self.state,
                snapshots: &mut self.snapshots,
                cache: &mut self.cache,
            },
        )
        .handle_ui_event(event);
    }
}
type Cpu = anyrender_vello_cpu::VelloCpuWindowRenderer;
struct Measured {
    renderer: Cpu,
    start: Instant,
    first: bool,
}
impl RenderContext for Measured {}
impl WindowRenderer for Measured {
    type ScenePainter<'a> = <Cpu as WindowRenderer>::ScenePainter<'a>;
    fn resume<F: FnOnce() + 'static>(
        &mut self,
        window: Arc<dyn anyrender::WindowHandle>,
        w: u32,
        h: u32,
        f: F,
    ) {
        self.renderer.resume(window, w, h, f);
    }
    fn complete_resume(&mut self) -> bool {
        self.renderer.complete_resume()
    }
    fn suspend(&mut self) {
        self.renderer.suspend();
    }
    fn is_active(&self) -> bool {
        self.renderer.is_active()
    }
    fn set_size(&mut self, w: u32, h: u32) {
        self.renderer.set_size(w, h);
    }
    fn render<F: FnOnce(&mut Self::ScenePainter<'_>)>(&mut self, f: F) {
        self.renderer.render(f);
        if !self.first {
            self.first = true;
            println!(
                "FIRST_PRESENT_US {}",
                self.start.elapsed().as_secs_f64() * 1e6
            );
            if std::env::var_os("RUNIC_MEASURE_EXIT").is_some() {
                std::process::exit(0);
            }
        }
    }
}
fn make_doc(state: &app::State, w: u32, h: u32) -> HtmlDocument {
    let html = format!(
        "<!doctype html><html><head><style>runic-text,runic-if{{display:contents}}{}</style></head><body>{}</body></html>",
        app::CSS,
        app::body(state)
    );
    let mut doc = HtmlDocument::from_html(
        &html,
        DocumentConfig {
            net_provider: Some(DataUriNetProvider::shared(None)),
            html_parser_provider: Some(Arc::new(blitz_html::HtmlProvider)),
            viewport: Some(Viewport::new(w, h, 1.0, ColorScheme::Light)),
            ..Default::default()
        },
    );
    for _ in 0..4 {
        doc.resolve(0.0);
    }
    doc
}
fn save_png(doc: &mut BaseDocument, w: u32, h: u32, file: &str) {
    let mut renderer = anyrender_vello_cpu::VelloCpuImageRenderer::new(w, h);
    let mut buffer = Vec::new();
    renderer.render_to_vec(
        |scene| blitz_paint::paint_scene(scene, doc, 1.0, w, h, 0, 0),
        &mut buffer,
    );
    let mut encoder = png::Encoder::new(std::fs::File::create(file).unwrap(), w, h);
    encoder.set_color(png::ColorType::Rgba);
    encoder.set_depth(png::BitDepth::Eight);
    encoder
        .write_header()
        .unwrap()
        .write_image_data(&buffer)
        .unwrap();
}
pub fn launch() {
    let start = Instant::now();
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().is_some_and(|a| a == "--headless") {
        let w = args[1].parse().unwrap();
        let h = args[2].parse().unwrap();
        let base = &args[3];
        let mut state = app::initial();
        let mut doc = make_doc(&state, w, h);
        let mut previous = cache(&state);
        let mut trace = vec![snapshot(&doc, &state)];
        if let Some(events) = args.get(4) {
            for e in events.split(',').filter(|s| !s.is_empty()) {
                let e = e.parse().unwrap();
                let clock = Instant::now();
                let changed = app::dispatch(&mut state, e);
                let writes = apply(&mut doc, &state, &changed, &mut previous);
                doc.resolve(0.0);
                let mut shot = snapshot(&doc, &state);
                shot["event"] = json!(e);
                shot["writes"] = json!(writes);
                shot["update_us"] = json!(clock.elapsed().as_secs_f64() * 1e6);
                trace.push(shot);
            }
        }
        save_png(&mut doc, w, h, &format!("{base}.png"));
        std::fs::write(
            format!("{base}.json"),
            serde_json::to_string_pretty(&trace).unwrap(),
        )
        .unwrap();
        return;
    }
    if args.first().is_some_and(|a| a == "--transitions") {
        let input = std::io::read_to_string(std::io::stdin()).unwrap();
        let cases: Value = serde_json::from_str(&input).unwrap();
        let results: Vec<Value> = cases
            .as_array()
            .unwrap()
            .iter()
            .map(|case| {
                let mut s = app::from_json(&case["from"]);
                app::dispatch(&mut s, case["event"].as_u64().unwrap() as usize);
                app::json(&s)
            })
            .collect();
        println!("{}", json!(results));
        return;
    }
    if args.first().is_some_and(|a| a == "--benchmark") {
        let mut state = app::initial();
        let mut doc = make_doc(&state, 800, 600);
        let mut previous = cache(&state);
        let mut samples = vec![];
        let mut writes = 0;
        assert!(!app::EVENTS.is_empty(), "benchmark requires events");
        for i in 0..120 {
            let clock = Instant::now();
            let changed = app::dispatch(&mut state, i % app::EVENTS.len());
            writes += apply(&mut doc, &state, &changed, &mut previous);
            doc.resolve(0.0);
            if i >= 20 {
                samples.push(clock.elapsed().as_secs_f64() * 1e6);
            }
        }
        println!(
            "{}",
            json!({"samples_us":samples,"writes":writes,"optimized":app::OPTIMIZE})
        );
        return;
    }
    let w = args
        .windows(2)
        .find(|p| p[0] == "--width")
        .map(|p| p[1].parse().unwrap())
        .unwrap_or(800);
    let h = args
        .windows(2)
        .find(|p| p[0] == "--height")
        .map(|p| p[1].parse().unwrap())
        .unwrap_or(600);
    let state = app::initial();
    let doc = make_doc(&state, w, h);
    println!("NATIVE_INITIAL {}", snapshot(&doc, &state));
    let _ = std::io::stdout().flush();
    let event_loop = if args.iter().any(|a| a == "--x11") {
        use winit::platform::x11::EventLoopBuilderExtX11;
        winit::event_loop::EventLoop::builder()
            .with_x11()
            .build()
            .unwrap()
    } else {
        create_default_event_loop()
    };
    let (proxy, receiver) = BlitzShellProxy::new(event_loop.create_proxy());
    let mut app = BlitzApplication::new(proxy, receiver);
    let renderer = Measured {
        renderer: Cpu::new(),
        start,
        first: false,
    };
    let previous = cache(&state);
    app.add_window(WindowConfig::with_attributes(
        Box::new(Native {
            doc,
            state,
            snapshots: vec![],
            cache: previous,
        }),
        renderer,
        winit::window::WindowAttributes::default()
            .with_title(app::TITLE)
            .with_surface_size(winit::dpi::LogicalSize::new(w, h)),
    ));
    event_loop.run_app(app).unwrap();
}
