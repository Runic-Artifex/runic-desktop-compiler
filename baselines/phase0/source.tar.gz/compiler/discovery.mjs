import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { lower } from './frontend.mjs';
import { hash, Diagnostic } from './collect.mjs';
import { repository, validateRule } from './mappings.mjs';

export async function discover(graph,out,{replay=false,provider}={}) {
  let failure;
  try {await lower(graph,{registry:false});}catch(error){failure=error;}
  if(failure?.code!=='E_MAPPING'||!failure.discovery)throw new Diagnostic('E_DISCOVERY','Discovery requires an unsupported local pure helper');
  const schema=await readFile(path.join(repository,'mappings/schema.json'),'utf8');
  const bundle={schema:1,instruction:'Propose a restricted reusable mapping. Inspect the helper implementation. No application names, paths, executable extensions, or certifications. Return mapping JSON only.',inputHash:graph.hash,diagnostic:failure.toJSON(),...failure.discovery,mappingSchema:JSON.parse(schema)};
  const input=JSON.stringify(bundle,null,2)+'\n';
  if(Buffer.byteLength(input)>65536)throw new Diagnostic('E_DISCOVERY_SIZE','Discovery bundle exceeds 64 KiB');
  await mkdir(out,{recursive:true});await writeFile(path.join(out,'bundle.json'),input);
  let bytes,identity;
  if(replay) {bytes=await readFile(path.join(repository,'mappings/replay/pure-clamp.json'),'utf8');identity={mode:'replay',provider:'compiler-owned-fixture',model:null,liveDiscovery:false};}
  else if(provider) {
    // Explicit command boundary: executable reads bounded JSON stdin, emits JSON stdout.
    // No shell interpolation, credentials, or stderr are retained in evidence.
    bytes=await new Promise((resolve,reject)=>{
      const child=spawn(provider,[],{stdio:['pipe','pipe','ignore']});let output='';
      const timer=setTimeout(()=>{child.kill('SIGKILL');reject(new Diagnostic('E_PROVIDER','Provider timed out after 60 seconds'));},60000);
      child.stdout.on('data',chunk=>{output+=chunk;if(output.length>65536){child.kill();reject(new Diagnostic('E_PROVIDER','Provider output exceeds 64 KiB'));}});
      child.on('error',reject);child.on('close',code=>{clearTimeout(timer);code===0?resolve(output):reject(new Diagnostic('E_PROVIDER',`Provider exited ${code}`));});child.stdin.end(input);
    });identity={mode:'external-provider-command',provider:path.basename(provider),model:process.env.RUNIC_MODEL_ID??null,liveDiscovery:false,liveProviderUnvalidated:true};
  } else throw new Diagnostic('E_PROVIDER','No authorized model interface configured. Pass --replay for a labeled provider-boundary experiment, or --provider /absolute/executable');
  const candidate=validateRule(JSON.parse(bytes));
  // Preserve model content and record invocation identity separately; no claim is certified here.
  await writeFile(path.join(out,'candidate.json'),bytes);
  const provenance={schema:1,...identity,promptHash:hash(bundle.instruction),inputHash:hash(input),applicationSourceHash:graph.hash,candidateHash:hash(bytes),heldOutSourceIncluded:false,candidateProvenance:candidate.provenance};
  await writeFile(path.join(out,'provenance.json'),JSON.stringify(provenance,null,2)+'\n');
  return provenance;
}
