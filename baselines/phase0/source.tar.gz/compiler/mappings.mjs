import ts from 'typescript';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import vm from 'node:vm';
import { hash, Diagnostic } from './collect.mjs';

export const repository = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const unwrap = n => ts.isParenthesizedExpression(n) ? unwrap(n.expression) : n;
export const clampPattern={op:'min',args:[{op:'max',args:[{op:'param',index:0},{op:'param',index:1}]},{op:'param',index:2}]};
export function validateRule(rule) {
  const keys=['schema','id','version','matcher','preconditions','lowering','capabilities','provenance','tests'];
  if(!rule||typeof rule!=='object'||keys.some(k=>!Object.hasOwn(rule,k))||Object.keys(rule).some(k=>!keys.includes(k))||rule.schema!==1||rule.id!=='pure-clamp'||rule.version!==1||!rule.provenance||!rule.tests)throw new Diagnostic('E_RULE','Unsupported mapping envelope');
  if(JSON.stringify(rule.matcher)!==JSON.stringify({kind:'pure-function',parameters:3,body:clampPattern}))throw new Diagnostic('E_RULE','Only the restricted pure-function clamp matcher is available');
  if(JSON.stringify(rule.preconditions)!==JSON.stringify({domain:'finite-integer',maxAbs:1000000,constantBounds:true,orderedBounds:true,evaluation:'pure-left-to-right'}))throw new Diagnostic('E_RULE','Unsupported mapping preconditions');
  if(JSON.stringify(rule.capabilities)!==JSON.stringify(['integer-min','integer-max']))throw new Diagnostic('E_RULE','Unknown required capabilities');
  let visited=0;
  const visit=p=>{
    if(++visited>15)throw new Diagnostic('E_RULE','Lowering exceeds resource limit');
    if(!p||typeof p!=='object')throw new Diagnostic('E_RULE','Invalid lowering');
    if(p.op==='param'){if(Object.keys(p).length!==2||!Number.isInteger(p.index)||p.index<0||p.index>2)throw new Diagnostic('E_RULE','Invalid parameter');}
    else if(['min','max'].includes(p.op)){if(Object.keys(p).length!==2||!Array.isArray(p.args)||p.args.length!==2)throw new Diagnostic('E_RULE','Invalid min/max');p.args.forEach(visit);}
    else throw new Diagnostic('E_RULE','Only param/min/max lowering operations are allowed');
  };visit(rule.lowering);
  const count=p=>1+(p.args??[]).reduce((s,x)=>s+count(x),0);if(count(rule.lowering)>15)throw new Diagnostic('E_RULE','Lowering exceeds resource limit');
  return rule;
}
export function matchHelper(fn,rule,checker,mathSymbol) {
  if(fn.parameters.length!==3||fn.asteriskToken||fn.type||fn.typeParameters||fn.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword)||fn.parameters.some(p=>!ts.isIdentifier(p.name)||p.type||p.initializer||p.dotDotDotToken||p.questionToken))return false;
  if(!fn.body||!ts.isBlock(fn.body)||fn.body.statements.length!==1||!ts.isReturnStatement(fn.body.statements[0]))return false;
  const params=fn.parameters.map(p=>checker.getSymbolAtLocation(p.name));
  const match=(n,p)=>{
    if(!n)return false;n=unwrap(n);
    if(p.op==='param')return ts.isIdentifier(n)&&checker.getSymbolAtLocation(n)===params[p.index];
    if(!ts.isCallExpression(n)||n.typeArguments?.length||!ts.isPropertyAccessExpression(n.expression)||n.expression.name.text!==p.op||!ts.isIdentifier(n.expression.expression)||checker.getSymbolAtLocation(n.expression.expression)!==mathSymbol||n.arguments.length!==2)return false;
    return n.arguments.every((a,i)=>match(a,p.args[i]));
  };
  return match(fn.body.statements[0].expression,rule.matcher.body);
}
export async function loadRegistry() {
  const lock=JSON.parse(await readFile(path.join(repository,'mappings/registry.lock.json'),'utf8'));
  const rules=[];
  for(const pinned of lock.rules) {
    if(!/^[-a-z0-9]+\.json$/.test(pinned.file))throw new Diagnostic('E_REGISTRY','Invalid rule filename');
    const bytes=await readFile(path.join(repository,'mappings/accepted',pinned.file),'utf8');
    if(hash(bytes)!==pinned.sha256)throw new Diagnostic('E_REGISTRY','Accepted rule hash mismatch');
    const rule=validateRule(JSON.parse(bytes));
    const proof=JSON.parse(await readFile(path.join(repository,pinned.evidence),'utf8'));
    if(!proof.accepted||proof.candidateHash!==pinned.sha256)throw new Diagnostic('E_REGISTRY','Rule lacks matching validation evidence');
    rules.push({...rule,sha256:pinned.sha256});
  }
  return rules;
}
const lower=(p,a)=>p.op==='param'?a[p.index]:Math[p.op](...p.args.map(x=>lower(x,a)));
export async function validateCandidate(candidatePath) {
  const bytes=await readFile(candidatePath,'utf8');if(Buffer.byteLength(bytes)>65536)throw new Diagnostic('E_RULE','Candidate exceeds 64 KiB');const rule=validateRule(JSON.parse(bytes));
  // Compiler-owned oracle, never candidate executable code or candidate tests.
  const context=vm.createContext(Object.create(null),{codeGeneration:{strings:false,wasm:false}});
  const reference=new vm.Script('(function(value, lower, upper) { return Math.min(Math.max(value, lower), upper); })').runInContext(context,{timeout:1000});
  let cases=0;
  for(let lo=-16;lo<=32;lo++)for(let hi=lo;hi<=32;hi++)for(let x=-16;x<=32;x++){
    const args=[x,lo,hi];if(!Object.is(reference(...args),lower(rule.lowering,args)))throw new Diagnostic('E_RULE_DIFFERENTIAL',`Counterexample ${JSON.stringify(args)}`);cases++;
  }
  const extremes=[-1000000,-999999,-64,-1,0,1,64,999999,1000000];
  for(const lo of extremes)for(const hi of extremes.filter(n=>n>=lo))for(const x of extremes){const a=[x,lo,hi];if(!Object.is(reference(...a),lower(rule.lowering,a)))throw new Diagnostic('E_RULE_DIFFERENTIAL',`Boundary counterexample ${a}`);cases++;}
  const applicable=a=>a.every(n=>Number.isInteger(n)&&!Object.is(n,-0)&&Math.abs(n)<=1e6)&&a[1]<=a[2];
  const negatives=[[0,5,1],[NaN,0,1],[Infinity,0,1],[-0,0,1],[1.5,0,2],[1000001,0,2],['1',0,2]];
  if(negatives.some(applicable))throw new Diagnostic('E_RULE_PRECONDITION','Invalid numeric input accepted');
  const corpus=[
    [true,'function renamed(a,b,c){return Math.min(Math.max(a,b),c);}'],
    [true,'function helper(value,lower,upper){return (Math.min((Math.max(value,lower)),upper));}'],
    [false,'function constrain(a,b,c){return Math.max(Math.min(a,c),b);}'],
    [false,'function constrain(a,b,c){console.log(a);return Math.min(Math.max(a,b),c);}'],
    [false,'function constrain(a,b,c){return Math.min(Math.max(b,a),c);}'],
    [false,'function constrain(a,b,c){const Math={};return Math.min(Math.max(a,b),c);}'],
    [false,'function constrain(a,b,Math){return Math.min(Math.max(a,b),Math);}'],
    [false,'async function constrain(a,b,c){return Math.min(Math.max(a,b),c);}'],
    [false,'function constrain(a=1,b,c){return Math.min(Math.max(a,b),c);}'],
    [false,'function constrain(a,b,...c){return Math.min(Math.max(a,b),c);}'],
    [false,'function constrain(a,b,c){return Math.min(Math.max(a++,b),c);}'],
  ];
  for(const [expected,source] of corpus) {
    const file='/__runic_mapping_corpus__.js',host=ts.createCompilerHost({allowJs:true,noEmit:true});
    const read=host.getSourceFile.bind(host);host.getSourceFile=(name,language,...rest)=>name===file?ts.createSourceFile(file,source,language,true):read(name,language,...rest);
    const program=ts.createProgram([file],{allowJs:true,noEmit:true},host),checker=program.getTypeChecker(),fn=program.getSourceFile(file).statements[0];
    const lib=program.getSourceFiles().filter(f=>program.isSourceFileDefaultLibrary(f)).flatMap(f=>[...f.statements]).find(n=>ts.isVariableStatement(n)&&n.declarationList.declarations.some(d=>d.name.getText()==='Math'));
    const math=checker.getSymbolAtLocation(lib.declarationList.declarations.find(d=>d.name.getText()==='Math').name);
    if(matchHelper(fn,rule,checker,math)!==expected)throw new Diagnostic('E_RULE_MATCHER',`Structural corpus failure: ${source}`);
  }
  const report={schema:1,accepted:true,candidateHash:hash(bytes),validator:'runic-independent-v1',oracle:'compiler-owned JavaScript Math.min(Math.max(value,lower),upper)',exhaustive:{range:[-16,32],orderedBounds:true,cases:60025},cases,negativeNumericCases:negatives.length,structuralCases:corpus.length,scope:'Restricted structural matcher + tested bounded numeric inputs; not a general JS equivalence proof'};
  return report;
}
export async function accept(candidatePath,evidencePath) {
  const report=await validateCandidate(candidatePath);
  const bytes=await readFile(candidatePath,'utf8');
  await mkdir(path.join(repository,'mappings/accepted'),{recursive:true});
  await writeFile(evidencePath,JSON.stringify(report,null,2)+'\n');
  await writeFile(path.join(repository,'mappings/accepted/pure-clamp.json'),bytes);
  await writeFile(path.join(repository,'mappings/registry.lock.json'),JSON.stringify({schema:1,rules:[{file:'pure-clamp.json',sha256:hash(bytes),evidence:path.relative(repository,evidencePath)}]},null,2)+'\n');
  return report;
}
