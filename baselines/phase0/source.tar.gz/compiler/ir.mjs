import { Diagnostic, hash } from './collect.mjs';

export const LIMIT = 1_000_000;
export const STATE_LIMIT = 64;
export function literal(value, source) { if(typeof value==='string'&&(/[\u0000-\u0008\u000b-\u001f\u007f]/u.test(value)||/[\uD800-\uDFFF]/u.test(value)))throw new Diagnostic('E_STRING','Text must contain Unicode scalar values without unsupported control characters',source);return { op:'literal', value, type:typeof value, effect:'pure', source }; }
export function deps(expr) {
  if (!expr || typeof expr !== 'object') return [];
  return [...new Set([...(expr.op === 'state' ? [expr.slot] : []), ...Object.values(expr).filter(v=>v && typeof v==='object' && v.op).flatMap(deps), ...(expr.args ?? []).flatMap(deps)])].sort((a,b)=>a-b);
}
const numeric = x => { if (!Number.isSafeInteger(x) || Object.is(x,-0) || Math.abs(x)>LIMIT) throw new Diagnostic('E_NUMBER', `Value ${x} leaves the exact finite-integer domain`); return x; };
export function evaluate(e, state, previous) {
  const ev = x => evaluate(x, state, previous);
  let v;
  switch(e.op) {
    case 'literal': v=e.value; break;
    case 'state': v=state[e.slot]; break;
    case 'previous': v=previous; break;
    case 'not': v=!ev(e.arg); break;
    case 'neg': v=-ev(e.arg); break;
    case 'select': v=ev(e.test) ? ev(e.yes) : ev(e.no); break;
    case 'and': v=ev(e.left) && ev(e.right); break;
    case 'or': v=ev(e.left) || ev(e.right); break;
    case 'add': v=ev(e.left)+ev(e.right); break;
    case 'sub': v=ev(e.left)-ev(e.right); break;
    case 'mul': v=ev(e.left)*ev(e.right); break;
    case 'eq': v=ev(e.left)===ev(e.right); break;
    case 'ne': v=ev(e.left)!==ev(e.right); break;
    case 'lt': v=ev(e.left)<ev(e.right); break;
    case 'le': v=ev(e.left)<=ev(e.right); break;
    case 'gt': v=ev(e.left)>ev(e.right); break;
    case 'ge': v=ev(e.left)>=ev(e.right); break;
    case 'min': v=Math.min(...e.args.map(ev)); break;
    case 'max': v=Math.max(...e.args.map(ev)); break;
    default: throw new Diagnostic('E_IR', `Unknown operation ${e.op}`);
  }
  return typeof v === 'number' ? numeric(v) : v;
}
export function render(ir, state) {
  const walk = node => {
    if (node.kind === 'text') return { id:node.id, kind:'text', text:node.parts.map(e => {const v=evaluate(e,state); return typeof v==='boolean' ? '' : String(v);}).join('') };
    if (node.kind === 'conditional') return evaluate(node.test,state) ? {id:node.id,kind:'conditional',children:node.children.map(walk)} : {id:node.id,kind:'conditional',children:[]};
    return { id:node.id,kind:'element',tag:node.tag,attrs:Object.fromEntries(Object.entries(node.attrs).map(([k,e])=>[k,evaluate(e,state)])),children:node.children.map(walk), event:node.event };
  };
  return walk(ir.ui);
}
export function eventNode(ir, event, state) {
  const visit = n => n.event === event ? n : (n.children ?? []).map(visit).find(Boolean);
  return visit(render(ir,state));
}
export function transition(ir, state, event) {
  const node = eventNode(ir,event,state);
  if (!node || node.attrs.disabled === true) return [...state];
  const next = [...state];
  for (const update of ir.handlers[event].updates) {
    const value = evaluate(update.value,state,next[update.slot]);
    if (typeof value !== typeof next[update.slot]) throw new Diagnostic('E_STATE_TYPE', 'State type must remain constant', update.source);
    if (typeof value === 'number' && Math.abs(value)>STATE_LIMIT) throw new Diagnostic('E_STATE_BOUND', `State transition reaches ${value}; accepted state domain is [-64,64]`,update.source);
    next[update.slot]=value;
  }
  return next;
}

export function validateIR(ir) {
  if (ir.schema !== 1 || !Array.isArray(ir.states) || !ir.ui || !ir.handlers) throw new Diagnostic('E_IR','Invalid IR envelope');
  if(ir.states.length>16||ir.states.some((s,i)=>s.id!==i||!['number','boolean'].includes(s.type)||typeof s.initial!==s.type))throw new Diagnostic('E_IR','Invalid state slot declaration');
  const ids = new Set();
  const expr = (e,previousType) => {
    if (!e || e.effect !== 'pure' || !['number','boolean','string'].includes(e.type)) throw new Diagnostic('E_IR','Invalid expression type/effect');
    const arity={literal:0,state:0,previous:0,not:1,neg:1,select:3,and:2,or:2,add:2,sub:2,mul:2,eq:2,ne:2,lt:2,le:2,gt:2,ge:2,min:2,max:2}[e.op];
    if(arity===undefined) throw new Diagnostic('E_IR',`Unknown expression ${e.op}`);
    if(e.op==='literal') { if(typeof e.value!==e.type) throw new Diagnostic('E_IR','Literal type mismatch'); literal(e.value,e.source); if(e.type==='number') numeric(e.value); }
    if(e.op==='state' && (!ir.states[e.slot] || ir.states[e.slot].type!==e.type)) throw new Diagnostic('E_IR','Invalid state reference');
    if(e.op==='previous'&&e.type!==previousType)throw new Diagnostic('E_IR','Previous value outside a typed update');
    const children=Object.values(e).filter(v=>v && typeof v==='object' && v.op).concat(e.args??[]);
    if(children.length!==arity) throw new Diagnostic('E_IR','Expression arity mismatch');
    children.forEach(c=>expr(c,previousType));
    const all=type=>children.every(c=>c.type===type);
    if(['add','sub','mul','min','max','neg'].includes(e.op)&&(!all('number')||e.type!=='number'))throw new Diagnostic('E_IR','Numeric operation type mismatch');
    if(['not','and','or'].includes(e.op)&&(!all('boolean')||e.type!=='boolean'))throw new Diagnostic('E_IR','Boolean operation type mismatch');
    if(['lt','le','gt','ge'].includes(e.op)&&(!all('number')||e.type!=='boolean'))throw new Diagnostic('E_IR','Comparison type mismatch');
    if(['eq','ne'].includes(e.op)&&(children[0].type!==children[1].type||e.type!=='boolean'))throw new Diagnostic('E_IR','Equality type mismatch');
    if(e.op==='select'&&(e.test.type!=='boolean'||e.yes.type!==e.no.type||e.type!==e.yes.type))throw new Diagnostic('E_IR','Selection type mismatch');
  };
  const walk=n=>{
    if(ids.has(n.id)||typeof n.id!=='string'||ids.size>=1024) throw new Diagnostic('E_IR','Invalid or duplicate UI identity'); ids.add(n.id);
    if(n.kind==='text') n.parts.forEach(e=>expr(e));
    else if(n.kind==='conditional') {expr(n.test); if(n.test.type!=='boolean') throw new Diagnostic('E_IR','Conditional type');}
    else if(n.kind==='element') {if(!['main','article','section','div','span','p','h1','h2','button','strong','small','header','footer'].includes(n.tag))throw new Diagnostic('E_IR','Unknown UI tag');for(const [key,e] of Object.entries(n.attrs)){if(!['id','class','disabled','title','aria-label','type'].includes(key)||e.type!==(key==='disabled'?'boolean':'string'))throw new Diagnostic('E_IR','Invalid UI attribute');expr(e);} if(n.event!==undefined && (!ir.handlers[n.event]||n.tag!=='button')) throw new Diagnostic('E_IR','Missing handler or invalid event target');}
    else throw new Diagnostic('E_IR','Unknown UI kind');
    (n.children??[]).forEach(walk);
  }; walk(ir.ui);
  for(const h of ir.handlers) for(const u of h.updates) {if(!ir.states[u.slot] || ir.states[u.slot].type!==u.value.type) throw new Diagnostic('E_IR','Update type');expr(u.value,ir.states[u.slot].type);}
  const initial=ir.states.map(s=>s.initial);
  initial.forEach(v=>{ if(typeof v==='number'){numeric(v);if(Math.abs(v)>STATE_LIMIT)throw new Diagnostic('E_STATE_BOUND','Invalid initial state');} });
  const queue=[initial], seen=new Set([JSON.stringify(initial)]), edges=[];
  for(let i=0;i<queue.length;i++) {
    const s=queue[i]; render(ir,s);
    for(let event=0;event<ir.handlers.length;event++) {
      const next=transition(ir,s,event); render(ir,next);
      edges.push({from:s,event,to:next});
      const key=JSON.stringify(next);
      if(!seen.has(key)) {seen.add(key);queue.push(next); if(queue.length>4096) throw new Diagnostic('E_STATE_SPACE','Reachability exceeds 4096 states');}
    }
  }
  ir.states.forEach((slot,i)=>{slot.domain=slot.type==='boolean' ? {kind:'boolean',values:[...new Set(queue.map(s=>s[i]))]} : {kind:'finite-integer',values:[...new Set(queue.map(s=>s[i]))].sort((a,b)=>a-b)};});
  ir.validation={reachableStates:queue.length,transitions:edges.length,transitionHash:hash(edges),domain:'exact integers |x| <= 1000000; state |x| <= 64'};
  return {ir,reachable:queue,edges};
}
