import { spawnSync } from 'node:child_process';
import { readFile,writeFile,stat } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import { hash } from '../compiler/collect.mjs';
function run(cmd,args,env={}){const r=spawnSync(cmd,args,{encoding:'utf8',timeout:30000,env:{...process.env,...env},maxBuffer:1024*1024});if(r.status!==0)throw new Error(r.stderr);return r.stdout;}
function stats(a){const s=[...a].sort((a,b)=>a-b);return {n:s.length,min:s[0],median:s[Math.floor(s.length/2)],max:s.at(-1),mean:s.reduce((a,b)=>a+b,0)/s.length};}
const results=[];
for(const folder of ['quantity','quantity-no-opt-release','thermostat']) {
  const binary=`artifacts/${folder}/runic-app`,build=JSON.parse(await readFile(`artifacts/${folder}/build.json`,'utf8'));
  const startup=[],updates=[];
  for(let i=0;i<8;i++){const start=performance.now();const out=run(binary,['--x11'],{RUNIC_MEASURE_EXIT:'1'});const elapsed=(performance.now()-start)*1000;startup.push({firstPresentFromMainUs:Number(out.match(/FIRST_PRESENT_US ([\d.]+)/)[1]),spawnToExitUs:elapsed});}
  for(let i=0;i<5;i++)updates.push(JSON.parse(run(binary,['--benchmark'])));
  const size=(await stat(binary)).size;
  const compressed=spawnSync('gzip',['-n','-9','-c',binary],{timeout:30000,maxBuffer:32*1024*1024});if(compressed.status!==0)throw new Error('gzip failed');
  results.push({folder,build,binarySha256:hash(await readFile(binary)),executableBytes:size,gzipExecutableBytes:compressed.stdout.length,startup,firstObservedStartup:startup[0],warmMainToFirstPresentUs:stats(startup.slice(1).map(s=>s.firstPresentFromMainUs)),warmSpawnToExitUpperBoundUs:stats(startup.slice(1).map(s=>s.spawnToExitUs)),updateRuns:updates,updateUs:stats(updates.flatMap(r=>r.samples_us)),updateMetric:'functional dispatch + changed-binding evaluation/mutation + style/layout resolve; excludes paint and presentation'});
}
const report={schema:1,conditions:'Linux/KDE X11 via XWayland, 800x600, scale 1, fixed bundled font. First observed run reported separately; page caches NOT evicted and no cold-start claim. Seven subsequent startup runs and five update runs (20 warmups + 100 samples each).',startupMetric:'Rust main entry to first softbuffer render/present return; spawn-to-process-exit upper bound includes loader and IPC scheduling. Compositor display acknowledgement not instrumented.',toolchain:{rust:run('rustc',['--version']).trim(),cargo:run('cargo',['--version']).trim(),node:process.version,kernel:run('uname',['-sr']).trim()},sourceHashes:{compiler:hash(await readFile('compiler/codegen.mjs')),runtime:hash(await readFile('native/runtime.rs')),cargoLock:hash(await readFile('Cargo.lock')),flakeLock:hash(await readFile('flake.lock'))},results};
await writeFile('evidence/measurements.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(results.map(({folder,executableBytes,gzipExecutableBytes,warmMainToFirstPresentUs,updateUs})=>({folder,executableBytes,gzipExecutableBytes,warmMainToFirstPresentUs,updateUs})),null,2));
