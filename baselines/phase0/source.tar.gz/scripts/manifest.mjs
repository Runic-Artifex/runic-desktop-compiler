import { readdir,readFile,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
const files=['.envrc','.gitignore','PROMPT.md','README.md','flake.nix','flake.lock','Cargo.toml','Cargo.lock','package.json','package-lock.json'];
async function walk(dir) {
  for(const entry of await readdir(dir,{withFileTypes:true})) {
    if(entry.name==='dist')continue;
    const name=`${dir}/${entry.name}`;
    if(entry.isDirectory())await walk(name);else if(entry.isFile())files.push(name);
  }
}
for(const root of ['compiler','native','fixtures','mappings','tests','scripts','docs'])await walk(root);
const inputs={};for(const file of files.sort())inputs[file]=sha256(await readFile(file));
const artifacts={};
for(const folder of ['quantity','quantity-no-opt-release','thermostat']) {
  const build=JSON.parse(await readFile(`artifacts/${folder}/build.json`,'utf8'));
  artifacts[folder]={...build,binarySha256:sha256(await readFile(`artifacts/${folder}/runic-app`))};
}
const manifest={schema:1,algorithm:'SHA-256',scope:'Final implementation, fixtures, documentation and lockfiles; generated artifacts and evidence excluded from source hash',sourceHash:sha256(JSON.stringify(inputs)),inputs,artifacts};
await writeFile('evidence/source-manifest.json',JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({files:files.length,sourceHash:manifest.sourceHash}));
