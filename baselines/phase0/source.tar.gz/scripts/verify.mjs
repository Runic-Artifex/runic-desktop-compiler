import { spawnSync } from 'node:child_process';
import { readFile,writeFile,mkdir } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { collect } from '../compiler/collect.mjs';
import { lower } from '../compiler/frontend.mjs';

function run(binary,args,input) {const r=spawnSync(binary,args,{input,encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(r.status,0,r.stderr);return r.stdout;}
await mkdir('artifacts/verification',{recursive:true});
const reports=[];
for(const app of ['quantity','thermostat']) {
  const {ir,edges}=await lower(await collect(`fixtures/${app}`));
  const built=JSON.parse(await readFile(`artifacts/${app}/ir.json`,'utf8'));assert.equal(built.irHash,ir.irHash,'Artifact is stale');
  const actual=JSON.parse(run(`artifacts/${app}/runic-app`,['--transitions'],JSON.stringify(edges)));
  assert.deepEqual(actual,edges.map(e=>e.to));
  reports.push({app,sourceHash:ir.sourceHash,irHash:ir.irHash,states:ir.validation.reachableStates,exhaustiveRustTransitions:edges.length});
}
const opt='artifacts/quantity/runic-app',base='artifacts/quantity-no-opt-release/runic-app';
for(const [name,binary] of [['optimized',opt],['baseline',base]])run(binary,['--headless','800','600',`artifacts/verification/${name}`,'3,2,0,3,3,1']);
const a=JSON.parse(await readFile('artifacts/verification/optimized.json','utf8')),b=JSON.parse(await readFile('artifacts/verification/baseline.json','utf8'));
for(let i=0;i<a.length;i++){assert.deepEqual(a[i].state,b[i].state);assert.deepEqual(a[i].elements,b[i].elements);}
for(const trace of [a,b])assert.equal(trace[1].elements.note.nodeIdentity,trace[2].elements.note.nodeIdentity,'Unrelated update remounts conditional subtree');
assert.deepEqual(await readFile('artifacts/verification/optimized.png'),await readFile('artifacts/verification/baseline.png'));
const tree=run('cargo',['tree','--locked','--manifest-path','artifacts/quantity/Cargo.toml','--edges','normal']);
assert.doesNotMatch(tree,/boa_engine|quickjs|javascriptcore|webkit|wry|tauri|v8|deno_core/i);
const report={schema:1,reports,optimizationPreservesDOMIdentity:true,optimizationPixelIdentical:true,engineDependencyScan:true};
await writeFile('evidence/backend-tests.json',JSON.stringify(report,null,2)+'\n');await writeFile('evidence/native-dependency-tree.txt',tree);
console.log(JSON.stringify(report,null,2));
