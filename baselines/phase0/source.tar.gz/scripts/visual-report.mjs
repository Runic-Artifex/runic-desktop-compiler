import { readFile,writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';

const reports=[];
for(const app of ['quantity','thermostat'])for(const width of [420,800]) {
  const geometry=JSON.parse(await readFile(`evidence/${app}-browser/report-${width}x600.json`,'utf8'));
  assert.equal(geometry.semanticsPassed,true);assert.equal(geometry.geometryPassed,true);
  const image=spawnSync('magick',['compare','-metric','MAE',`evidence/${app}-browser-${width}x600.png`,`evidence/${app}-native-${width}x600.png`,'null:'],{encoding:'utf8'});
  assert.ok([0,1].includes(image.status),image.stderr);
  const normalized=Number(image.stderr.match(/\(([^)]+)\)/)[1]);
  let maximumDelta=0;
  for(const r of geometry.results)for(const id of Object.keys(r.browser))for(const key of ['x','y','width','height'])maximumDelta=Math.max(maximumDelta,Math.abs(r.browser[id].rect[key]-r.native[id].rect[key]));
  reports.push({app,width,height:600,cases:geometry.cases,semanticsPassed:true,geometryTolerancePx:2,maximumObservedGeometryDeltaPx:maximumDelta,pixelMeanAbsoluteError8Bit:normalized*255,pixelToleranceMeanAbsolute8Bit:3,pixelPassed:normalized*255<=3,browser:`${app}-browser-${width}x600.png`,native:`${app}-native-${width}x600.png`,sourceHash:geometry.sourceHash,irHash:geometry.irHash});
}
const report={schema:1,comparison:'Real browser screenshot from T3 collaborative preview vs native CPU renderer framebuffer at scale 1; initial state, same fixed font and source. Geometry/text/disabled/classes also checked after every reachable event pair. Native framebuffer images are not OS window screenshots. Native OS input verified separately.',pixelMetric:'ImageMagick normalized mean absolute channel error converted to 8-bit units; tolerance 3/255. This permits rasterizer/antialiasing differences, not geometry drift. No reference image rewriting.',reports};
await writeFile('evidence/visual-comparison.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(reports,null,2));assert.ok(reports.every(r=>r.pixelPassed),'Pixel comparison exceeded tolerance');
