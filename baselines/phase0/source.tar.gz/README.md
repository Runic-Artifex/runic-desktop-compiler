# Runic Desktop Compiler

A research compiler from a deliberately small React subset to Rust + Blitz, with **no JavaScript engine in the generated application**. Vite collects original source and assets; TypeScript ASTs and resolved symbols lower components to a validated framework-independent IR; the backend emits ordinary Rust state transitions and live DOM bindings.

The quantity picker and thermostat use the same source in the browser and compiler. No fixture-name recognizers, hand-translated native application, screenshots-as-UI, Chromium, WebView, Bun fork, or sibling SDK integration are involved.

| Checkpoint | Actual status |
|---|---|
| A: native compiler/input | Implemented; genuine native windows and mouse input verified |
| B: semantics/optimization | 106 reachable transitions match Rust; 212 browser/native cases pass semantics and geometry across two sizes. One strict pixel comparison remains outside tolerance; keyboard delivery is unverified |
| C: dictionary growth | Rejection → explicit replay proposal → independent validation → pinned acceptance → unchanged held-out reuse demonstrated. **Live LLM discovery remains unvalidated** |

Read [the compatibility contract](docs/CONTRACT.md) before trying another application, and [the evidence report](docs/EVIDENCE.md) for measurements, reproduction commands, and limitations.

From this Git repository on x86_64 Linux:

```sh
nix develop .
npm ci
npm test
node compiler/cli.mjs analyze fixtures/quantity
node compiler/cli.mjs build fixtures/quantity --release
node compiler/cli.mjs build fixtures/thermostat --release
./artifacts/quantity/runic-app --x11
```

The default native launch also supports Wayland; X11 via XWayland was used for desktop input verification because this machine's Wayland screenshot portal failed. The generated program needs shared native libraries exposed by the development shell or the packaged launcher. Its CSS/font are embedded. Node is required only for compilation and reference verification.

For direnv, inspect `.envrc`, then `direnv allow` and `direnv exec . <command>`. It uses the normal Git-aware `use flake`. Keep `artifacts`, `target`, `.cache`, and `node_modules` ignored. Alternatively create a reusable environment with `nix develop . --profile .cache/dev-profile -c true`, then run `nix develop .cache/dev-profile -c <command>` until the flake or lockfile changes.

The accepted rule ships pinned. Reproduce dictionary growth without changing the registry first:

```sh
# Expected E_MAPPING, with a source location:
node compiler/cli.mjs analyze fixtures/quantity --no-mappings
node compiler/cli.mjs discover fixtures/quantity --replay --out artifacts/discovery
node compiler/cli.mjs validate artifacts/discovery/candidate.json
node compiler/cli.mjs accept artifacts/discovery/candidate.json
node compiler/cli.mjs build fixtures/thermostat --release
# Expected E_MAPPING_PRECONDITION:
node compiler/cli.mjs analyze fixtures/incompatible
```

`discover --provider /absolute/executable` provides a bounded stdin/stdout boundary for a user-authorized model wrapper. External command identity and candidate provenance are recorded; executing an arbitrary wrapper does not establish a live model call. Normal analyze/build never calls a model. Proposal and acceptance are separate operations.

For an actual browser comparison, build first, then run `node compiler/cli.mjs compare fixtures/quantity --port 5173`. Open `http://localhost:5173/?runicCase=0` in the T3 collaborative preview at 800×600 or 420×600. The page replays all reachable state/event pairs through the original React DOM and saves comparison evidence. Thermostat uses the same command with port 5174. `npm run verify` checks the compiled Rust transitions and optimization independently.

Packaging: `node scripts/package.mjs quantity` creates a launcher/application archive and a separate compressed Nix runtime closure under `artifacts/distribution/quantity`. Both archives comprise the deployment; consult `IMPORT.txt`. See the report for complete installed and compressed sizes.
